package POM;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BasicUtilities.Browsers;
import BasicUtilities.JustWait;
import BasicUtilities.ScreenShotss;
import ExcelDataUtils.ReadExcel;


public class NewTest extends ReadExcel{
	
	Browsers bs;
	JustWait jw;
	ScreenShotss ss;
	WebDriver dr;
	
	String url="https://www.saucedemo.com/"; 
	
	AdvancedSearchPage asp;
	HomePage hp;
	UserPage up;
	@BeforeClass
	public void getdata()
	{
		ReadExcel();
	}
	
	private void ReadExcel() {
		// TODO Auto-generated method stub
		ReadExcel();
	}

	@BeforeMethod
	public void bm()
	{
		
		bs=new Browsers();
		dr=bs.launchBrowser("chrome", url);
	}
	
	@Test(dataProvider="login_data")
	public void test1()
	{
		asp=new AdvancedSearchPage(dr);
		asp.AdvancedSearchPage();
		
		hp=new HomePage(dr);
		hp.clkLogin();
		
		up=new UserPage(dr);
		up.UserPage();
	}

	@DataProvider(name="login_data")
	public String[][] provide_data()
	{
//		String[][] data= {
//							{"standard_user","secret_sauce"},
//							{"performance_glitch_user","secret_sauce"}
//						 };
		return testdata;
		
	}
}
