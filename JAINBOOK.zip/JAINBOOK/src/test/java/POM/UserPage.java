package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BasicUtilities.JustWait;
import BasicUtilities.ScreenShotss;
import BasicUtilities.logger;

public class UserPage {
	
	WebDriver dr;
	logger log;
	ScreenShotss ss;
	JustWait wt;
	
	public UserPage(WebDriver dr)
	{
	this.dr = dr;
	log =new logger(dr);
	ss=new ScreenShotss(dr);
	wt = new JustWait(dr);
	}
	
	public void clkAdvancedSearch()
	{
		By by_ele = By.xpath("//input[@id='btnsubmit0']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.click();
	}

	public void UserPage() {
		// TODO Auto-generated method stub
		
	}
	
	
}
