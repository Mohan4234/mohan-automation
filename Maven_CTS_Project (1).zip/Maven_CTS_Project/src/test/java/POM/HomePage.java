package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BasicUtilities.JustWait;
import BasicUtilities.ScreenShotss;
import BasicUtilities.logger;

public class HomePage {
	WebDriver dr;
	logger log;
	ScreenShotss ss;
	JustWait wt;
	
	public HomePage(WebDriver dr)
	{
	this.dr = dr;
	log =new logger(dr);
	ss=new ScreenShotss(dr);
	wt = new JustWait(dr);
	}
	
	public void clkLogin()
	{
		By by_ele = By.xpath("//a[text()='Login']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we= wt.elementToBeClickable(by_ele,10);
		we.click();
	}
	
	public void DoLogin(String username, String password)
	{
		By by_ele = By.xpath("//input[@placeholder='Enter Email']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.sendKeys(username);
		
		by_ele = By.xpath("//input[@placeholder='Enter Password']");
		we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.sendKeys(password);
		
		by_ele = By.xpath("//input[@onclick='dologin(); return false;']");
		we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.click();
	}
	
	public void clkRegister()
	{
		By by_ele = By.xpath("//input[@id='btnsubmit0']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.click();
	}
	
	public void DoRegister(String Email,String RepeatEmail,String password,String Repeatpassword)
	{
		By by_ele = By.xpath("//input[@placeholder='Enter Email']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.sendKeys(Email);
		
		by_ele = By.xpath("//input[@placeholder='Repeat Email Address']");
		we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.sendKeys(RepeatEmail);
		
		by_ele = By.xpath("//input[@placeholder='Password']");
		we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.sendKeys(password);
		
		by_ele = By.xpath("//input[@placeholder='Repeat Password']");
		we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.sendKeys(Repeatpassword);
		
		by_ele = By.xpath("//input[@id='ContentPlaceHolder1_btnsubmit']");
		we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.click();;
		
	}
	
	public String RegisterErrorMessage()
	{
		By by_ele = By.xpath("//input[@placeholder='Enter Email']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		return we.getText();
		
	}
	
	public String RegisterEmailMatchError()
	{
		By by_ele = By.xpath("//div[contains(text(),'Email Do Not Match')]");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		return we.getText();
		
	}

	public String RegisterPwdMatchError()
	{
		By by_ele = By.xpath("//div[contains(text(),'Password Do Not Match')]");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		return we.getText();
	}
	
	public String LoginPwdInvalid()
	{
		By by_ele = By.xpath("//div[contains(text(),'Password Is Invalid')]");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		return we.getText();
	}
	
	public String LoginEmailInvalid()
	{
		By by_ele = By.xpath("//div[contains(text(),'Not A Valid Email Id')]");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		return we.getText();
	}
	
	
}
